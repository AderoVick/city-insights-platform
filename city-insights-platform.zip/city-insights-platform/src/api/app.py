from fastapi import FastAPI
from pydantic import BaseModel
import joblib
from pathlib import Path
import numpy as np

app = FastAPI(title="City Insights API", version="0.1.0")

MODEL_PATH = Path('models/model.pkl')
model = None
if MODEL_PATH.exists():
    model = joblib.load(MODEL_PATH)

class Row(BaseModel):
    traffic_flow: float
    avg_speed_kmh: float
    temp_c: float
    humidity: float
    rain_mm: float
    pm25: float
    pm25_lag1: float
    pm25_lag2: float
    flow_lag1: float
    speed_lag1: float
    is_rush: int

@app.get("/health")
def health():
    return {"status":"ok","model_loaded": MODEL_PATH.exists()}

@app.post("/predict")
def predict(row: Row):
    global model
    if model is None and MODEL_PATH.exists():
        model = joblib.load(MODEL_PATH)
    if model is None:
        # fallback: simple heuristic
        pred = 0.6*row.pm25 + 0.3*row.pm25_lag1 + 0.1*row.pm25_lag2 + (10 if row.is_rush else 0)
        return {"pm25_next": float(pred), "note":"heuristic (train a model to improve)"}
    x = np.array([[row.traffic_flow,row.avg_speed_kmh,row.temp_c,row.humidity,row.rain_mm,
                   row.pm25,row.pm25_lag1,row.pm25_lag2,row.flow_lag1,row.speed_lag1,row.is_rush]])
    pred = model.predict(x)[0]
    return {"pm25_next": float(pred)}
