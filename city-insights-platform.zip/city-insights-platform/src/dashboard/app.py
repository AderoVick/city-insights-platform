import streamlit as st
import pandas as pd
from pathlib import Path
import requests

st.set_page_config(page_title="City Insights", layout="wide")

st.title("🏙️ City Insights Dashboard")
st.caption("Mobility + Air Quality (synthetic data)")

df = pd.read_csv(Path('data/processed/clean_timeseries.csv'))
st.sidebar.header("Filters")
city = st.sidebar.selectbox("City", sorted(df['city'].unique()))
metric = st.sidebar.selectbox("Metric", ["traffic_flow","avg_speed_kmh","pm25","temp_c","humidity","rain_mm"])

cdf = df[df['city']==city]

st.subheader(f"{metric} over time — {city}")
st.line_chart(cdf[[metric]])

st.subheader("Quick KPIs")
c1,c2,c3 = st.columns(3)
c1.metric("Avg PM2.5", f"{cdf['pm25'].mean():.1f}")
c2.metric("Avg Speed (km/h)", f"{cdf['avg_speed_kmh'].mean():.1f}")
c3.metric("Traffic Flow (p90)", f"{cdf['traffic_flow'].quantile(0.9):.0f}")

st.subheader("Predict Next-Hour PM2.5")
last = cdf.sort_values(['date','hour']).iloc[-1]
payload = {
    "traffic_flow": float(last["traffic_flow"]),
    "avg_speed_kmh": float(last["avg_speed_kmh"]),
    "temp_c": float(last["temp_c"]),
    "humidity": float(last["humidity"]),
    "rain_mm": float(last["rain_mm"]),
    "pm25": float(last["pm25"]),
    "pm25_lag1": float(cdf.iloc[-2]["pm25"]) if len(cdf)>1 else float(last["pm25"]),
    "pm25_lag2": float(cdf.iloc[-3]["pm25"]) if len(cdf)>2 else float(last["pm25"]),
    "flow_lag1": float(cdf.iloc[-2]["traffic_flow"]) if len(cdf)>1 else float(last["traffic_flow"]),
    "speed_lag1": float(cdf.iloc[-2]["avg_speed_kmh"]) if len(cdf)>1 else float(last["avg_speed_kmh"]),
    "is_rush": int(last["hour"] in list(range(7,10)) + list(range(16,20)))
}
st.code(payload, language="json")

api_url = st.text_input("API URL", "http://localhost:8000/predict")
if st.button("Predict"):
    try:
        r = requests.post(api_url, json=payload, timeout=5)
        st.success(r.json())
    except Exception as e:
        st.error(f"Could not reach API: {e}")
