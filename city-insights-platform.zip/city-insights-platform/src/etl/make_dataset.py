from pathlib import Path
import pandas as pd

RAW = Path('data/raw/city_timeseries.csv')
PROCESSED = Path('data/processed/clean_timeseries.csv')
PROCESSED.parent.mkdir(parents=True, exist_ok=True)

def main():
    df = pd.read_csv(RAW, parse_dates=['date'])
    # Basic cleaning
    df = df.sort_values(['city','date','hour']).reset_index(drop=True)
    # Clip weird negatives
    for col in ['traffic_flow','avg_speed_kmh','temp_c','humidity','pm25','rain_mm']:
        df[col] = df[col].clip(lower=0)
    df.to_csv(PROCESSED, index=False)
    print(f'Wrote {PROCESSED} with {len(df)} rows')

if __name__ == '__main__':
    main()
