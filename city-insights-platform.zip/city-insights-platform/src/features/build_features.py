from pathlib import Path
import pandas as pd

CLEAN = Path('data/processed/clean_timeseries.csv')
FEAT = Path('data/processed/features.csv')

def main():
    df = pd.read_csv(CLEAN, parse_dates=['date'])
    # Lag features for pm25 (target next-hour pm25)
    df['pm25_next'] = df.groupby('city')['pm25'].shift(-1)
    df['pm25_lag1'] = df.groupby('city')['pm25'].shift(1)
    df['pm25_lag2'] = df.groupby('city')['pm25'].shift(2)
    df['flow_lag1'] = df.groupby('city')['traffic_flow'].shift(1)
    df['speed_lag1'] = df.groupby('city')['avg_speed_kmh'].shift(1)
    df['is_rush'] = ((df['hour'].between(7,9)) | (df['hour'].between(16,19))).astype(int)
    df = df.dropna().reset_index(drop=True)
    df.to_csv(FEAT, index=False)
    print(f'Wrote {FEAT} with {len(df)} rows')

if __name__ == '__main__':
    main()
