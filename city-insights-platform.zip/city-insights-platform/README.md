# City Insights Platform

An end‑to‑end analytics project that simulates **mobility + air quality** data for multiple cities, builds a predictive model for **PM2.5**, serves predictions via a **FastAPI** microservice, and visualizes insights with a **Streamlit** dashboard.

Perfect for a portfolio: clear structure, realistic pipeline, and runnable demos—no external APIs required.

## What’s inside
- **ETL:** generate/clean synthetic time‑series data
- **Features:** create model-ready features
- **Model:** train a RandomForest to predict next‑hour PM2.5
- **API:** FastAPI endpoint `POST /predict` to score new rows
- **Dashboard:** Streamlit app for KPIs, charts, and live predictions
- **Notebooks:** quick EDA and sanity checks
- **Tests:** lightweight unit tests for core pieces
- **Docker:** containerize the API + dashboard

## Quickstart
```bash
# 1) Environment
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# 2) Make processed data & features
python -m src.etl.make_dataset
python -m src.features.build_features

# 3) Train model (creates models/model.pkl)
python -m src.models.train_model

# 4) Run API (http://localhost:8000/docs)
uvicorn src.api.app:app --reload

# 5) Run Dashboard (http://localhost:8501)
streamlit run src/dashboard/app.py
```

## Repo structure
```
.
├─ data/
│  ├─ raw/                # synthetic raw
│  └─ processed/          # clean + features
├─ notebooks/             # EDA/model sanity
├─ src/
│  ├─ etl/                # data generation / cleaning
│  ├─ features/           # feature engineering
│  ├─ models/             # training + artifacts
│  ├─ api/                # FastAPI service
│  └─ dashboard/          # Streamlit app
├─ tests/
├─ Dockerfile
├─ Makefile
├─ requirements.txt
├─ README.md
└─ LICENSE
```

## Next steps (ideas)
- Replace synthetic generator with real open datasets
- Add forecasting (Prophet / statsmodels)
- Add CI (GitHub Actions) to run tests and lint
- Deploy API to Render/Fly.io and Streamlit Cloud for the UI

MIT © 2025 Victor Bornface
